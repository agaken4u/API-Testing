package restApiTest.restApiTest;

/**
 * Hello world!
 *
 */
public class SampleProject 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
