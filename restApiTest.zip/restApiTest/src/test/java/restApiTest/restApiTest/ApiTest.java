/**
 * 
 */
package restApiTest.restApiTest;

import org.junit.Before;
import org.junit.Test;

import com.google.gson.JsonObject;

import static com.jayway.restassured.RestAssured.given;



public class ApiTest extends RestUtilities {

	private String basePath;

	@Before
	public void setup() {
		basePath = "https://podium-slns-interview.getsandbox.com";
	}

	
	@Test
	public void getProduct_TS1001() {
		given().when().get(basePath + "/products").then().statusCode(200);
	}
	
	@Test
	public void validateMinAge_TS1002() {
		JsonObject loanPayload = new JsonObject();
        loanPayload.addProperty("name", "tester1");
        loanPayload.addProperty("age", 18);
        loanPayload.addProperty("mortgageAmount", 4000);
        loanPayload.addProperty("propertyValue", 5000);
        
		given().contentType("application/json").body(loanPayload).when().post(basePath + "/products/1/applications").then().statusCode(200).log().all();
	}
	
	@Test
	public void validateMinAge_TS1003() {
		JsonObject loanPayload = new JsonObject();
        loanPayload.addProperty("name", "tester1");
        loanPayload.addProperty("age", 17);
        loanPayload.addProperty("mortgageAmount", 4000);
        loanPayload.addProperty("propertyValue", 5000);
        
		given().contentType("application/json").body(loanPayload).when().post(basePath + "/products/1/applications").then().statusCode(400).log().all();
	}
	
	@Test
	public void validateMaxAge_TS1004() {
		JsonObject loanPayload = new JsonObject();
        loanPayload.addProperty("name", "tester1");
        loanPayload.addProperty("age", 70);
        loanPayload.addProperty("mortgageAmount", 4000);
        loanPayload.addProperty("propertyValue", 5000);
        
		given().contentType("application/json").body(loanPayload).when().post(basePath + "/products/1/applications").then().statusCode(200).log().all();
	}
	
	@Test
	public void validateMaxAge_TS1005() {
		JsonObject loanPayload = new JsonObject();
        loanPayload.addProperty("name", "tester1");
        loanPayload.addProperty("age", 71);
        loanPayload.addProperty("mortgageAmount", 4000);
        loanPayload.addProperty("propertyValue", 5000);
        
		given().contentType("application/json").body(loanPayload).when().post(basePath + "/products/1/applications").then().statusCode(400).log().all();
	}
}









