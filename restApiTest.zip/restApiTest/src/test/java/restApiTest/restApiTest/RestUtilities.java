package restApiTest.restApiTest;

import io.restassured.RestAssured;

public class RestUtilities {
    
	public static void setBaseURI (String baseURI){
        RestAssured.baseURI = baseURI;
    }
	
	public static void setBasePath(String basePathTerm){
        RestAssured.basePath = basePathTerm;
    }
}
